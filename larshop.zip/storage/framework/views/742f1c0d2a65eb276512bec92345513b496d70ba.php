<div class="mb-5">
    <h5>Categories:</h5>
    <ul class="list-group">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item"><a href="<?php echo e(route('shop.category', ['category' => $category->id])); ?>" class="text-dark"><?php echo e($category->title); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<div class="text-left align-bottom ">
    <h5>Tags:</h5>
    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="#" class="btn btn-secondary float-left mb-2 mr-2"><?php echo e($tag->title); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="clearfix"></div>
</div>
<?php /**PATH E:\wamp\www\larshop\resources\views/shop/sidebar.blade.php ENDPATH**/ ?>