<div class="row">
    <div class="col-md-12">
        <nav class="navbar navbar-expand-lg navbar-light pl-0 bg-light">
            <a class="navbar-brand" href="/">Main</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('shop.index')); ?>">Shop</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('cart.index')); ?>">Cart</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<?php /**PATH E:\wamp\www\larshop\resources\views/nav.blade.php ENDPATH**/ ?>