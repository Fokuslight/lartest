<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">
            <div class="row mb-5">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php echo $__env->make('shop.card', compact('product'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="pagination flex justify-content-center">
                <?php echo e($products->links()); ?>

            </div>
        </div>
        <div class="col-md-4">
            <?php echo $__env->make('shop.sidebar', compact('categories', 'tags'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\larshop\resources\views/shop/index.blade.php ENDPATH**/ ?>