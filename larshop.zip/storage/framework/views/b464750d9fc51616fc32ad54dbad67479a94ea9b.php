<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">
            <h5><?php echo e($product->title); ?></h5>
                        <div class="p-2 card">

                            <div>
                                <img src="" alt="">
                            </div>
                            <div class="mb-2">
                                <?php echo e($product->description); ?>

                            </div>
                            <div class="mb-2">
                                <?php echo e($product->content); ?>

                            </div>
                            <div class="mb-2">
                                $<?php echo e($product->price); ?>

                            </div>
                            <div>
                                <a href="" class="btn btn-primary">Buy</a>
                            </div>
                        </div>
        </div>
        <div class="col-md-4">
                <?php echo $__env->make('shop.sidebar', compact('categories', 'tags'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\larshop\resources\views/shop/show.blade.php ENDPATH**/ ?>