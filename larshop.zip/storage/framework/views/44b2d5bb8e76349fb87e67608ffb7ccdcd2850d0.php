
<div class="col-md-4 p-2 ">
    <div class="p-3 card">
        <h5 class="m-0"><a
                href="<?php echo e(route('shop.category.show', ['category' => $product->category, 'product' => $product->id])); ?>"><?php echo e($product->title); ?></a>
        </h5>
        <div>
            <img src="" alt="">
        </div>
        <div class="mb-2">
            <?php echo e($product->description); ?>

        </div>
        <div class="mb-2">
            $<?php echo e($product->price); ?>

        </div>
        <div>
            <form action="<?php echo e(route('cart.update', ['product' => $product->id])); ?>" method="post">
            <button type="submit" class="btn btn-primary">Buy</button>
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>
</div>
<?php /**PATH E:\wamp\www\larshop\resources\views/shop/card.blade.php ENDPATH**/ ?>